# anki-show-question
Add-on for anki that adds the ability to show the question again without submitting an ease.

The functionality of the easy-button is changed to show the question again.
Also, a context-menu entry in the reviewer is added.
